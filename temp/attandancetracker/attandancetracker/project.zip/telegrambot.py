from flask import Flask, request, render_template, jsonify
import ast
import re
import requests

app = Flask(__name__)

# Core logic from existing app (DO NOT MODIFY)
def calculate(username, password):
    session = requests.Session()
    login_url = "http://mitsims.in/studentAppLogin/studentLogin.action"
    login_params = {
        "actionType": "studentAppLogin",
        "personType": "student",
        "userId": username,
        "password": password
    }
    try:
        login_response = session.get(login_url, params=login_params)
        login_data = ast.literal_eval(login_response.text)
        if login_data["status"] == "success":
            student_id = login_data["studentLoginDetails"][0]["id"]
            token = login_data["studentLoginDetails"][0]["authToken"]
        else:
            return None
    except Exception:
        return None

    attendance_url = "http://mitsims.in/studentApp/getAttendanceDetails.action"
    attendance_params = {
        "tkn": token,
        "stdnt.id": student_id,
        "studentId": student_id,
        "actionType": "attendanceDetails",
        "studentType": "student"
    }
    try:
        attendance_response = session.get(attendance_url, params=attendance_params)
        js_text = attendance_response.text
        subject_blocks = re.findall(r'\{(.*?)\}', js_text, re.DOTALL)
        cleaned_attendance = {}
        for block in subject_blocks:
            try:
                subject = re.search(r"subjectName\s*:\s*'([^']+)'", block).group(1).strip()
                attended = int(re.search(r"attended\s*:\s*'([^']+)'", block).group(1).strip())
                total = int(re.search(r"conducted\s*:\s*'([^']+)'", block).group(1).strip())
                percentage = float(re.search(r"percentage\s*:\s*'([^']+)'", block).group(1).strip())
                cleaned_attendance[subject] = {
                    'attended': attended,
                    'total_classes': total,
                    'percentage': percentage
                }
            except AttributeError:
                continue
        return cleaned_attendance
    except Exception:
        return None

def process_attendance_data(data, threshold=75):
    if not data:
        return None
    
    subjects = []
    overall_attended = 0
    overall_total = 0
    
    for subject, details in data.items():
        attended = details['attended']
        total = details['total_classes']
        percent = details['percentage']
        overall_attended += attended
        overall_total += total
        
        if percent >= threshold:
            max_skip = int(attended / (threshold/100) - total)
            action = f"Can skip {max_skip} class(es)" if max_skip > 0 else "No skip"
            need_to_attend = 0
        else:
            need_to_attend = int(((threshold/100)*total - attended)/(1 - threshold/100) + 0.9999)
            action = f"Need to attend {need_to_attend} class(es)"
            max_skip = 0
            
        subjects.append({
            'name': subject,
            'attended': attended,
            'total': total,
            'percentage': percent,
            'action': action,
            'max_skip': max_skip,
            'need_to_attend': need_to_attend,
            'status': 'safe' if percent >= threshold else 'danger'
        })
        
    overall_percent = (overall_attended / overall_total * 100) if overall_total > 0 else 0
    if overall_percent >= threshold:
        overall_skip = int(overall_attended / (threshold/100) - overall_total)
        overall_need = 0
    else:
        overall_skip = 0
        overall_need = int(((threshold/100)*overall_total - overall_attended)/(1 - threshold/100) + 0.9999)
        
    return {
        'subjects': subjects,
        'overall': {
            'attended': overall_attended,
            'total': overall_total,
            'percentage': round(overall_percent, 2),
            'max_skip': overall_skip,
            'need_to_attend': overall_need
        }
    }

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/attendance", methods=["POST"])
def get_attendance():
    data = request.get_json()
    roll = data.get("roll")
    password = data.get("password")
    
    raw_data = calculate(roll, password)
    if raw_data:
        processed = process_attendance_data(raw_data)
        return jsonify({"status": "success", "data": processed})
    else:
        return jsonify({"status": "error", "message": "Login failed or data unavailable"}), 401

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
