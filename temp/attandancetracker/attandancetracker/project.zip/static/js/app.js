document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const loginModal = document.getElementById('login-modal');
    const dashboard = document.getElementById('dashboard');
    const loginError = document.getElementById('login-error');
    const loginBtn = document.getElementById('login-btn');
    const loginSpinner = document.getElementById('login-spinner');
    
    let attendanceData = null;
    let pieChart = null;
    let barChart = null;

    // Dark Mode Toggle
    const darkModeBtn = document.getElementById('dark-mode-toggle');
    const html = document.documentElement;
    
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        html.classList.add('dark');
        darkModeBtn.querySelector('i').classList.replace('fa-moon', 'fa-sun');
    }

    darkModeBtn.addEventListener('click', () => {
        html.classList.toggle('dark');
        const isDark = html.classList.contains('dark');
        localStorage.theme = isDark ? 'dark' : 'light';
        darkModeBtn.querySelector('i').classList.replace(isDark ? 'fa-moon' : 'fa-sun', isDark ? 'fa-sun' : 'fa-moon');
    });

    // Login Handler
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const roll = document.getElementById('roll').value;
        const password = document.getElementById('password').value;

        loginBtn.disabled = true;
        loginSpinner.classList.remove('hidden');
        loginError.classList.add('hidden');

        try {
            const response = await fetch('/api/attendance', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ roll, password })
            });

            const result = await response.json();

            if (result.status === 'success') {
                attendanceData = result.data;
                document.getElementById('user-display').textContent = roll;
                initDashboard(attendanceData);
                loginModal.classList.add('opacity-0', 'scale-95');
                setTimeout(() => {
                    loginModal.classList.add('hidden');
                    dashboard.classList.remove('hidden');
                    dashboard.classList.add('animate-in', 'fade-in', 'duration-500');
                }, 300);
            } else {
                throw new Error(result.message);
            }
        } catch (err) {
            loginError.textContent = err.message || 'Connection failed';
            loginError.classList.remove('hidden');
        } finally {
            loginBtn.disabled = false;
            loginSpinner.classList.add('hidden');
        }
    });

    function initDashboard(data) {
        // Top stats with animation
        animateValue('overall-percent', 0, data.overall.percentage, 1000);
        animateValue('overall-attended', 0, data.overall.attended, 1000);
        animateValue('overall-skip', 0, data.overall.max_skip, 1000);
        animateValue('overall-need', 0, data.overall.need_to_attend, 1000);

        const statusLabel = document.getElementById('overall-status');
        if (data.overall.percentage >= 75) {
            statusLabel.textContent = 'Safe';
            statusLabel.className = 'px-3 py-1 rounded-full text-xs font-bold uppercase bg-green-100 text-green-700';
        } else {
            statusLabel.textContent = 'Warning';
            statusLabel.className = 'px-3 py-1 rounded-full text-xs font-bold uppercase bg-red-100 text-red-700';
        }

        renderCharts(data);
        renderTable(data.subjects);
    }

    function animateValue(id, start, end, duration) {
        const obj = document.getElementById(id);
        const range = end - start;
        const startTime = new Date().getTime();
        const timer = setInterval(() => {
            const timePassed = new Date().getTime() - startTime;
            let progress = timePassed / duration;
            if (progress > 1) progress = 1;
            obj.innerText = (start + progress * range).toFixed(progress === 1 && Number.isInteger(end) ? 0 : 2);
            if (progress === 1) clearInterval(timer);
        }, 16);
    }

    function renderCharts(data) {
        const ctxPie = document.getElementById('pieChart').getContext('2d');
        const ctxBar = document.getElementById('barChart').getContext('2d');
        
        const labels = data.subjects.map(s => s.name.length > 20 ? s.name.substring(0, 20) + '...' : s.name);
        const percentages = data.subjects.map(s => s.percentage);
        
        if (pieChart) pieChart.destroy();
        if (barChart) barChart.destroy();

        pieChart = new Chart(ctxPie, {
            type: 'doughnut',
            data: {
                labels: ['Attended', 'Missed'],
                datasets: [{
                    data: [data.overall.attended, data.overall.total - data.overall.attended],
                    backgroundColor: ['#3b82f6', '#e5e7eb'],
                    borderWidth: 0
                }]
            },
            options: { cutout: '70%', plugins: { legend: { position: 'bottom' } } }
        });

        barChart = new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Attendance %',
                    data: percentages,
                    backgroundColor: percentages.map(p => p >= 75 ? '#10b981' : '#ef4444'),
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, max: 100 } },
                plugins: { legend: { display: false } }
            }
        });
    }

    function renderTable(subjects) {
        const list = document.getElementById('subject-list');
        list.innerHTML = '';
        
        subjects.forEach(s => {
            const row = document.createElement('tr');
            row.className = 'hover:bg-gray-50/80 dark:hover:bg-gray-800/80 transition-colors';
            
            const colorClass = s.percentage >= 75 ? 'bg-secondary' : 'bg-danger';
            const badgeClass = s.percentage >= 75 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';

            row.innerHTML = `
                <td class="px-6 py-4">
                    <div class="font-medium text-sm md:text-base">${s.name}</div>
                    <div class="text-xs text-gray-500">${s.attended}/${s.total} classes</div>
                </td>
                <td class="px-6 py-4 w-48">
                    <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div class="${colorClass} h-2 rounded-full transition-all duration-1000" style="width: ${s.percentage}%"></div>
                    </div>
                </td>
                <td class="px-6 py-4 font-bold text-sm">${s.percentage}%</td>
                <td class="px-6 py-4 text-xs font-medium">
                    <span class="${s.percentage >= 75 ? 'text-secondary' : 'text-danger'}">
                        <i class="fas ${s.percentage >= 75 ? 'fa-check' : 'fa-exclamation-triangle'} mr-1"></i>
                        ${s.action}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded-md text-[10px] font-bold uppercase ${badgeClass}">
                        ${s.percentage >= 75 ? 'Stable' : 'Risk'}
                    </span>
                </td>
            `;
            list.appendChild(row);
        });
    }

    // Search and Sort
    document.getElementById('search-input').addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        const filtered = attendanceData.subjects.filter(s => s.name.toLowerCase().includes(term));
        renderTable(filtered);
    });

    document.getElementById('sort-select').addEventListener('change', (e) => {
        const val = e.target.value;
        let sorted = [...attendanceData.subjects];
        if (val === 'percent-desc') sorted.sort((a, b) => b.percentage - a.percentage);
        if (val === 'percent-asc') sorted.sort((a, b) => a.percentage - b.percentage);
        renderTable(sorted);
    });

    // Exports
    document.getElementById('download-csv').addEventListener('click', () => {
        let csv = 'Subject,Attended,Total,Percentage,Action\n';
        attendanceData.subjects.forEach(s => {
            csv += `"${s.name}",${s.attended},${s.total},${s.percentage},"${s.action}"\n`;
        });
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `attendance_${document.getElementById('user-display').textContent}.csv`;
        a.click();
    });

    document.getElementById('download-pdf').addEventListener('click', () => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.text("MITS Attendance Report", 14, 15);
        doc.autoTable({
            startY: 20,
            head: [['Subject', 'Attended', 'Total', '%', 'Action']],
            body: attendanceData.subjects.map(s => [s.name, s.attended, s.total, s.percentage + '%', s.action])
        });
        doc.save(`attendance_report.pdf`);
    });

    document.getElementById('logout-btn').addEventListener('click', () => {
        window.location.reload();
    });
});
